#ifndef SRC_METADATA_H_
#define SRC_METADATA_H_

#include "nan.h"

NAN_METHOD(metadata);

#endif  // SRC_METADATA_H_
