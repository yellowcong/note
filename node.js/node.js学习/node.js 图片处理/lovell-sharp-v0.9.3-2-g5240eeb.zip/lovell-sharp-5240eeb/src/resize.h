#ifndef SRC_RESIZE_H_
#define SRC_RESIZE_H_

#include "nan.h"

NAN_METHOD(resize);

#endif  // SRC_RESIZE_H_
